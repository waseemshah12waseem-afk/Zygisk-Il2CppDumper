# Build IL2CppManager for Android 15 (ARM64)

## Important: AIDE Plus 2.0.3

This project uses Kotlin, Jetpack Compose, Android Gradle Plugin, and native C++/CMake.
The APK previously uploaded from AIDE was not a valid compiled app: its `classes.dex`
was only 2,736 bytes and its Kotlin `.kt` source files were copied into the APK as
loose files. Do not install that APK.

AIDE Plus 2.0.3 is not a reliable build path for this project's Kotlin/Compose toolchain.
This package includes a GitHub Actions workflow to build it with the official Android
Gradle Plugin and NDK instead.

## Build from your phone

1. Extract this ZIP.
2. Upload the `IL2CppManager-main` folder contents to a new GitHub repository.
3. Open the repository's **Actions** tab.
4. Select **Android ARM64 APK** and tap **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, find **Artifacts**, and download
   `IL2CppManager-Android15-arm64-debug`.
7. Extract the artifact and install `app-debug.apk`.

The build is configured for:
- Android minimum API 26 (Android 8.0+)
- target/compile API 35
- ARM64 (`arm64-v8a`) only
- JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin 2.0.21
- NDK 26.3.11579264 and CMake 3.22.1

This workflow is a build setup, not proof that compilation has succeeded. If the workflow
fails, share the first actual compiler or linker error from its log.
